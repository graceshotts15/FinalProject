import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;

import java.util.Scanner;

import javax.swing.ImageIcon;

import java.util.Scanner;

import java.awt.Container; 
import java.awt.GridLayout;
import java.awt.BorderLayout;
public class SoftballManagement {
	
	
	
	class SoftballManagementFrame extends JFrame {
		public SoftballManagementFrame() {
			setBounds(200,200,1200,800);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			

	        Container contentPane = getContentPane();
	        contentPane.setLayout(new BorderLayout());

	        JPanel buttonPanel = new JPanel();
	        contentPane.add(buttonPanel, BorderLayout.SOUTH);

	        JPanel contactGridPanel = new JPanel();
	        contentPane.add(contactGridPanel, BorderLayout.CENTER);
	        contactGridPanel.setLayout(new GridLayout(4,8));

	     
	        Container frame = null;
			frame.add(new JLabel(new ImageIcon("Downloads/field2.png")));
			
			
		}
		
	}

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		Scanner input2 = new Scanner (System.in);
		System.out.println("Create Your Softball Team Roster");
		
		int players = 0;
		int x = 0;
		while(x==0) {
			x = 0;
		System.out.println("How many players do you have?");
		players = input.nextInt();
		if(players<9 || players>12) {
			System.out.println("Try Again! Only 9-12 players allowed!");
		} else {
			x = 1;
		}
		}
		
	
		for(int j=0; j<players; j++) {
			
		System.out.println("What is your player's name?");
		String name = input2.nextLine();
		
		System.out.println("What is their team number?");
		int number = input.nextInt();
		
		System.out.println("What is their position?");
		int pos = input.nextInt();
		}
		
		
		
		
		
		
        //SoftballManagementFrame mySoftballManagementFrame = new SoftballManagementFrame();
       // mySoftballManagementFrame.setVisible(true);

	}

}
